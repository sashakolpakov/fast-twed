"""
TWED distance computation based on Numba JIT
"""

from .twed import twed
